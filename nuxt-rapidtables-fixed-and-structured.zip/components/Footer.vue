
<template>
  <footer class="bg-gray-100 text-center text-sm py-4 border-t mt-6">
    <p>&copy; 2025 RapidTables Clone. All rights reserved.</p>
  </footer>
</template>
