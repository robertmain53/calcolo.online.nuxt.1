import { defineNuxtConfig } from 'nuxt/config'

export default defineNuxtConfig({
  modules: [
    '@nuxtjs/i18n',
    '@nuxtjs/tailwindcss',
    '@nuxtjs/robots',
    '@nuxtjs/sitemap'
  ],
  i18n: {
    locales: ['en', 'it', 'es', 'fr'],
    defaultLocale: 'en',
    vueI18n: './i18n.config.ts'
  },
  sitemap: {
    siteUrl: 'https://example.com',
    gzip: true,
    routes: async () => {
      const calculators = await import('./content/calculators.json').then(m => m.default)
      return calculators.map(c => `/en/calculators/${c.slug}`)
    }
  },
  tailwindcss: {
    viewer: false
  }
})