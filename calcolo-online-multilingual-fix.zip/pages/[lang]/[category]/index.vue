
<template>
  <div class="p-6">
    <h1 class="text-2xl font-bold mb-4">Category: {{ $route.params.category }}</h1>
    <ul class="space-y-2">
      <li v-for="calc in filtered" :key="calc.slug" class="border-b pb-2">
        <NuxtLink :to="`/${$route.params.lang}/calculators/${calc.slug}`" class="text-blue-600 hover:underline">
          {{ calc.title }}
        </NuxtLink>
        <p class="text-sm text-gray-500">{{ calc.description }}</p>
      </li>
    </ul>
  </div>
</template>

<script setup>
import calculators from '~/content/calculators.json'
const route = useRoute()
const filtered = calculators.filter(c => c.category.toLowerCase() === route.params.category.toLowerCase())
</script>
